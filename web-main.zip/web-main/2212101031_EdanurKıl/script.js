//Öneri kısmındaki resimlerin animasyonu
ScrollReveal().reveal('.im1', { delay: 250 });
ScrollReveal().reveal('.im2', { delay: 500 });
ScrollReveal().reveal('.im3', { delay: 750 });
ScrollReveal().reveal('.im4', { delay: 1000 });
ScrollReveal().reveal('.im5', { delay: 1250 });
ScrollReveal().reveal('.im6', { delay: 1500 });
ScrollReveal().reveal('.im7', { delay: 1750 });
ScrollReveal().reveal('.im8', { delay: 2000 });
ScrollReveal().reveal('.im9', { delay: 2250 });
ScrollReveal().reveal('.im10', { delay: 2500 });
ScrollReveal().reveal('.im11', { delay: 2750 });
ScrollReveal().reveal('.im12', { delay: 3000 });

//panellerin sağdan ve soldan kayarak gelmesi
window.sr=ScrollReveal();
sr.reveal('.animatedleft',{
    origin: 'left',
    duration: 1000,
    distance: '25rem',
    delay: 300
})
sr.reveal('.animatedright',{
    origin: 'right',
    duration: 1000,
    distance: '25rem',
    delay: 300
})

//Resim galerisi sağa sola geçiş

const carousel = document.querySelector(".carousel"),
firstImg = carousel.querySelectorAll("img")[0],
arrowIcons = document.querySelectorAll(".wrapper i");
let isDragStart = false, isDragging = false, prevPageX, prevScrollLeft, positionDiff;
const showHideIcons = () => {
    let scrollWidth = carousel.scrollWidth - carousel.clientWidth; 
    arrowIcons[0].style.display = carousel.scrollLeft == 0 ? "none" : "block";
    arrowIcons[1].style.display = carousel.scrollLeft == scrollWidth ? "none" : "block";
}
arrowIcons.forEach(icon => {
    icon.addEventListener("click", () => {
        let firstImgWidth = firstImg.clientWidth + 14;
        carousel.scrollLeft += icon.id == "left" ? -firstImgWidth : firstImgWidth;
        setTimeout(() => showHideIcons(), 60);
    });
});
const autoSlide = () => {
    if(carousel.scrollLeft - (carousel.scrollWidth - carousel.clientWidth) > -1 || carousel.scrollLeft <= 0) return;
    positionDiff = Math.abs(positionDiff); 
    let firstImgWidth = firstImg.clientWidth + 14;
    let valDifference = firstImgWidth - positionDiff;
    if(carousel.scrollLeft > prevScrollLeft) { 
        return carousel.scrollLeft += positionDiff > firstImgWidth / 3 ? valDifference : -positionDiff;
    }
    carousel.scrollLeft -= positionDiff > firstImgWidth / 3 ? valDifference : -positionDiff;
}
const dragStart = (e) => {
    isDragStart = true;
    prevPageX = e.pageX || e.touches[0].pageX;
    prevScrollLeft = carousel.scrollLeft;
}
const dragging = (e) => {
    if(!isDragStart) return;
    e.preventDefault();
    isDragging = true;
    carousel.classList.add("dragging");
    positionDiff = (e.pageX || e.touches[0].pageX) - prevPageX;
    carousel.scrollLeft = prevScrollLeft - positionDiff;
    showHideIcons();
}
const dragStop = () => {
    isDragStart = false;
    carousel.classList.remove("dragging");
    if(!isDragging) return;
    isDragging = false;
    autoSlide();
}
carousel.addEventListener("mousedown", dragStart);
carousel.addEventListener("touchstart", dragStart);
document.addEventListener("mousemove", dragging);
carousel.addEventListener("touchmove", dragging);
document.addEventListener("mouseup", dragStop);
carousel.addEventListener("touchend", dragStop);